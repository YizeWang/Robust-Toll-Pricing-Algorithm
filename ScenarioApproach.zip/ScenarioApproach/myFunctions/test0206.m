%% network construction
clc
clear all
close all

nameNetwork1   = 'SimpleGeneralNetwork';
nameNetwork2   = 'SiouxFalls';
nameNetwork3   = 'Brasse';
pathDataFolder = '..\myRealData\';

nameNetwork = nameNetwork2;
G = ParseTNTP(pathDataFolder, nameNetwork);
PlotNetwork(G);

%% load demands
ODs = readmatrix([pathDataFolder nameNetwork2 '\SiouxFalls_ODs.csv']);

%% construct affine latency functions
numEdge = G.numedges;
G.Edges.Power = ones(numEdge, 1);

[A, b] = GetEqualityConstraints(G, ODs);

c = G.Edges.FreeFlowTime;
a = G.Edges.FreeFlowTime .* G.Edges.B ./ G.Edges.Capacity;

x = sdpvar(40204, 1);

obj = sum(0.5 * a .* x(1:76) .* x(1:76) + c .* x(1:76));
cons = [x >= 0, A*x == b];

tic
ops = sdpsettings('solver', 'gurobi', 'verbose', 1);
optimize(cons, obj, ops);
t1 = toc

tic
[x3, it3, xs3] = CompNashFlowFW3(G, ODs);
t3 = toc;