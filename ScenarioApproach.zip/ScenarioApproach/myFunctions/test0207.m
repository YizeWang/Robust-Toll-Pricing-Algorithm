%% network construction
clc
clear all
close all

nameNetwork1   = 'SimpleGeneralNetwork';
nameNetwork2   = 'SiouxFalls';
nameNetwork3   = 'Brasse';
pathDataFolder = '..\myRealData\';

nameNetwork = nameNetwork2;
G = ParseTNTP(pathDataFolder, nameNetwork);
ODs = readmatrix([pathDataFolder nameNetwork2 '\SiouxFalls_ODs.csv']);
% PlotNetwork(G);

% extract dimensions
M = G.numedges;   % number of edges
N = G.numnodes;   % number of nodes
K = size(ODs, 1); % number of demands

% extract vector values
FFT = G.Edges.FreeFlowTime;
B   = G.Edges.B;
Pow = G.Edges.Power;
Cap = G.Edges.Capacity;
Cap = ones(numel(Cap), 1);

% l(x) = ax + c
as = FFT .* B ./ Cap;
cs = FFT;

% Ax = b
[A, b] = GetEqualityConstraints(G, ODs);
b = full(b);

% auxiliary variables
xDim = M + M * K;
uDim = xDim;
aDim = M + N * K;
bDim = M + N * K;
ADim = [bDim, xDim];
tDim = M;
vDim = xDim + tDim + uDim + aDim;

%% construct gurobi parameters
% construct objective function
model.Q = sparse(vDim, vDim);         % quadratic terms in objective function
model.Q(1:M, 1:M) = sparse(diag(as)); % quadratic terms in objective function
model.obj = zeros(1, vDim);           % linear terms in objective function
model.obj(1:M) = cs';                 % linear terms in objective function

% equality constraint (1)
A11as = sparse(xDim, xDim);
A11as(1:M, 1:M) = sparse(diag(as));
A11 = [A11as, sparse(xDim, tDim), sparse(xDim, uDim), sparse(xDim, aDim)];
A12 = [sparse(xDim, xDim), sparse(xDim, tDim), -speye(xDim), sparse(xDim, aDim)];
A13 = [sparse(xDim, xDim), sparse(xDim, tDim), sparse(xDim, uDim), sparse(A)'];
A1 = A11 + A12 + A13;
b1 = -cs;
sense1 = repmat('=', numel(b1), 1);

% equality constraint (2)
A2 = [A, zeros(bDim, tDim), zeros(bDim, uDim), zeros(bDim, aDim)];
b2 = [b; zeros(M*K, 1)];
sense2 = repmat('=', numel(b2), 1);

% non-negative inequalities (3-4)
A31 = [speye(xDim), sparse(xDim, tDim), sparse(xDim, uDim), sparse(xDim, aDim)];
A32 = [sparse(uDim, xDim), sparse(uDim, tDim), speye(uDim), sparse(uDim, aDim)];
A3 = [A31; A32];
b3 = zeros(xDim+uDim, 1);
sense3 = repmat('>', numel(b3), 1);

% complementary slackness
Qc = sparse(xDim+tDim+uDim+aDim, xDim+tDim+uDim+aDim);
Qc(1:xDim, xDim+tDim+1:xDim+tDim+uDim) = 0.5 * speye(xDim);
Qc(xDim+tDim+1:xDim+tDim+uDim, 1:xDim) = 0.5 * speye(xDim);
qc = sparse(vDim, 1);
rhs = 0;

%% construct model
model.A = [A1; A2; A3];
model.rhs = [b1; b2; b3]';
model.sense = [sense1; sense2; sense3];
model.quadcon.Qc = Qc;
model.quadcon.q = qc;
model.quadcon.rhs = rhs;
params.NonConvex = 2;

%% compute results
results = gurobi(model, params);









