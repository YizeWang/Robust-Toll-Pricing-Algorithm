function [] = PrintValue(type, value)

    fprintf(type);
    fprintf(': %f\n', value);
    
end