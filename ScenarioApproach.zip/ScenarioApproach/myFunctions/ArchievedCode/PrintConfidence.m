function [] = PrintConfidence(epsilon, failureRisk)

    fprintf('With Prob of %f, the Optimal Tolls are %f-Level Robustly Feasible\n', 1-failureRisk, epsilon)

end

